#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT/Runtime"
exec "$ROOT/Runtime/SolidArcWorkspace" --options "$ROOT/Runtime/SolidArcWorkspace.toml" --open "$ROOT/Liger.solidarc" "$@"
