LIGER / TARGETED NURBS REFINEMENT / 01 NOV 2026

Open CAD/Liger_Refined_CAD.step in a STEP surface-model capable CAD application,
or CAD/Liger_Refined_CAD.solidarc in a compatible rebuilt SolidArc.
306 faces in three OPEN SHEET parts, not a closed manufacturing solid / Class-A.

Changes: three strip interfaces per half removed, two arch patches faired,
whole roof/glass-frame insert translated DOWN 1 mm to clear protrusion.
Main-shell outer rails retained. Some tight trailing arch returns remain.
REPORT.md distinguishes completed improvements from remaining limitations.

No new native GUI binary or interactive viewer is included in this ZIP.
Old W95 application executables were NOT rebuilt. Native audit uses Frontier
82ed251267ed8457ca3530d8228b91555572c25d plus the W95 overlay and BOTH
NURBS importer patches shipped in Tools/Patches/. Rebuild for that native path.
The deliberate real-gap fixture is test input, NOT production CAD.

The interactive comparison viewer requires the complete repository's original,
Faired and Refined folders. Clone/download the repository and run
python Tools/serve_refined.py 8080 from SolidArc/Vehicles/Liger.

Full report, viewer and reproducible tools:
https://github.com/SultanAladin/Slate/tree/arena/4f335fa8-slate/SolidArc/Vehicles/Liger/Refined
