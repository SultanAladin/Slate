@echo off
setlocal EnableExtensions DisableDelayedExpansion
if not exist "%~dp0Liger.solidarc" goto MissingProject
if not exist "%~dp0Runtime\SolidArcWorkspace.exe" goto MissingRuntime
pushd "%~dp0Runtime"
if errorlevel 1 goto MissingRuntime
"%~dp0Runtime\SolidArcWorkspace.exe" --options "%~dp0Runtime\SolidArcWorkspace.toml" --open "%~dp0Liger.solidarc"
set "Result=%ERRORLEVEL%"
popd
if not "%Result%"=="0" (
  echo SolidArc exited with error %Result%. Check your Vulkan graphics driver.
  pause
)
exit /b %Result%
:MissingProject
echo Liger.solidarc is missing. Extract the entire ZIP before starting.
pause
exit /b 1
:MissingRuntime
echo The Runtime folder is missing or inaccessible. Extract the entire ZIP before starting.
pause
exit /b 1
