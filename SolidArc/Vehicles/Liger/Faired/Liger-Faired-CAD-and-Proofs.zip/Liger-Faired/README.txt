LIGER / FAIRED NURBS CAD + STATIC PROOFS / 01 NOV 2026

Open CAD/Liger_Macro_CAD.solidarc in a compatible rebuilt SolidArc, or
CAD/Liger_Macro_CAD.step in a STEP surface-model capable CAD application.
Three exterior sheet parts, not a closed manufacturing solid or Class-A model.
56 mirrored faces faired; 312 total. Original boundary curves preserved.

IMPORTANT: old W95 GUI binaries are NOT rebuilt in this package. They may
refuse the main shell. The included NURBS iso-boundary importer patch must
be applied to the W95-overlay source and the application rebuilt, as explained
in REPORT.md and the linked original review. No native GUI executable included.

Proofs/ contains computed before/after shaded and zebra PNGs, actual shape-change
map, source distance map, and validation logs. REPORT.md has the full measured
results and remaining limitations. Source deviation is NOT a smoothness score.

The interactive comparison viewer is NOT in this CAD-only ZIP. To use it,
clone/download the repository, preserving both the original and Faired folders,
then run python Tools/serve_faired.py 8080 from SolidArc/Vehicles/Liger.
Repository revision/report and all reproducible tools:
https://github.com/SultanAladin/Slate/tree/arena/4f335fa8-slate/SolidArc/Vehicles/Liger/Faired
Original review and native rebuild requirements:
https://github.com/SultanAladin/Slate/blob/2473d49/SolidArc/Vehicles/Liger/README.md
